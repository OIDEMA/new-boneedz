<section id="sponsor" class="section">
    <div class="container">
        <!-- <h2 class="text-center mt-4 mb-4">協賛企業</h2> -->
        <div class="row d-flex justify-content-center">
            <div class="col-lg-6 d-flex justify-content-center align-items-center">
                <a href="https://www.otsuka.co.jp/" target="_blank">
                    <img src="https://boneedz.com/wp-content/uploads/2021/05/大塚製薬株式会社.jpeg" />
                </a>
            </div>

            <div class="col-lg-6 d-flex justify-content-center align-items-center">
                <a href="https://www.otsuka.co.jp/bdm/" target="_blank">
                    <img src="https://boneedz.com/wp-content/uploads/2021/05/og.png" />
                </a>
            </div>
        </div>
    </div>
</section>