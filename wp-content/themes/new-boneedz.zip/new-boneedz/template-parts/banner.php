<section class="mt-4">
  <a href="<?php echo home_url('/contact/') ?>"> 
    <img src="<?php $upload_dir = wp_upload_dir(); echo $upload_dir['baseurl']; ?>/2020/09/202009top01-1024x334.jpg" alt="" style="width: 100%; object-fit: cover;">
  </a>
</section>

<section class="mb-4">
  <a href="<?php echo home_url('/contact/') ?>">
    <img src="<?php $upload_dir = wp_upload_dir(); echo $upload_dir['baseurl']; ?>/2019/09/バナー.jpg" alt="" class="img-fluid">
  </a>
</section>