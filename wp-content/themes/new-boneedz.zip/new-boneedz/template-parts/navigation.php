<nav id="navbar" class="navbar order-last order-lg-0">
    <ul>
        <li><a class="nav-link" href="/qna">QnA</a></li>
        <li><a class="nav-link" href="/staff-2">スタッフ紹介</a></li>
        <li><a class="nav-link" href="/service">コース・料金</a></li>
        <!-- <li><a class="nav-link" href="/extensive">短期集中プログラム</a></li> -->
        <li><a class="nav-link" href="/beforeafter">Before After</a></li>
        <li><a class="nav-link" href="/blogs/">BLOG</a></li>
        <li><a class="nav-link" href="<?php echo home_url('/contact/') ?>">お問い合わせ</a></li>
    </ul>
    <i class="bi bi-list mobile-nav-toggle"></i>
</nav>