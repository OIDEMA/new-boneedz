<nav id="navbar" class="navbar order-last order-lg-0">
    <ul>
        <li><a class="nav-link" href="<?php echo home_url('/qna/') ?>">QnA</a></li>
        <li><a class="nav-link" href="<?php echo home_url('/staff-2/') ?>">スタッフ紹介</a></li>
        <li><a class="nav-link" href="<?php echo home_url('/service/') ?>">コース・料金</a></li>
        <li><a class="nav-link" href="<?php echo home_url('/extensive/') ?>">短期集中プログラム</a></li>
        <li><a class="nav-link" href="<?php echo home_url('/beforeafter/') ?>">Before After</a></li>
        <li><a class="nav-link" href="<?php echo home_url('/blogs/') ?>">BLOG</a></li>
        <li><a class="nav-link" href="<?php echo home_url('/contact/') ?>">お問い合わせ</a></li>
    </ul>
    <i class="bi bi-list mobile-nav-toggle"></i>
</nav>